# XO for Android

XO is a native Kotlin and Jetpack Compose Android assistant project. The project is intended to be uploaded to GitHub and built there; the source ZIP is the main deliverable.

## Download and upload XO

1. Download `XO.zip`.
2. Extract it to a folder named `XO`.
3. Create a GitHub repository.
4. Upload all extracted project files, including:
   - `gradlew`
   - `gradlew.bat`
   - `gradle/wrapper/gradle-wrapper.jar`
   - `gradle/wrapper/gradle-wrapper.properties`
   - `app/src/main/`
   - `.github/workflows/android.yml`
5. Commit and push the files to the `main` or `master` branch.

Do not upload `.research/`, `tools/`, `logo folder/`, `.gradle/`, `build/`, `app/build/`, local secrets, API keys, or Telegram tokens. The included `.gitignore` excludes these local/generated items.

## Open in Android Studio

1. Open Android Studio.
2. Choose **Open** and select the extracted XO project folder.
3. Let Android Studio sync the Gradle project.
4. Use JDK 17.

The project pins Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and minimum SDK 26.

## Build an APK with GitHub Actions

1. Open the repository on GitHub.
2. Click **Actions**.
3. Choose **Build XO Android Debug APK**.
4. Click **Run workflow** or push to `main`/`master`.
5. Wait for the workflow to finish.
6. Open the completed run and download the **xo-debug-apk** artifact.

The artifact contains `app-debug.apk` when GitHub Actions successfully completes the build.

## Build locally

Linux/macOS:

```sh
./gradlew --no-daemon :app:testDebugUnitTest
./gradlew --no-daemon :app:assembleDebug
```

Windows:

```bat
gradlew.bat --no-daemon :app:testDebugUnitTest
gradlew.bat --no-daemon :app:assembleDebug
```

The local APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## API and provider setup

XO supports an OpenAI-compatible HTTPS chat provider. API keys are entered in the app under **Settings** and encrypted using Android Keystore. Conversation history is stored locally in SQLite. Messages and recent context may be sent to the provider you configure; do not enter sensitive text if you do not want it sent to that provider.

## Current verification status

- Source files, Gradle configuration, manifest, tests, and GitHub workflow are included.
- The complete Gradle wrapper is included.
- This workspace cannot run Gradle or Android builds and has no APK artifact.
- GitHub Actions must complete successfully before this project should be considered compiled and installable.
- APK launch, provider calls, microphone recognition, TTS, wake word, Android automation, notification access, Telegram bot polling, and real-device behavior remain to be tested on a supported build environment or device.

## Feature status

See `docs/STATUS.md`. XO does not include smart-home, finance-tracker, charging-telemetry, or airspace-radar features.

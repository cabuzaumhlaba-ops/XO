package com.xo.assistant

import com.xo.assistant.data.ConversationMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ConversationValidationTest {
    @Test
    fun conversationLimitIsBounded() {
        assertThrows(IllegalArgumentException::class.java) { validateLimit(0) }
        assertThrows(IllegalArgumentException::class.java) { validateLimit(101) }
        assertEquals(12, validateLimit(12))
    }

    @Test
    fun onlyUserAndAssistantRolesAreAccepted() {
        assertEquals("user", validateRole("user"))
        assertEquals("assistant", validateRole("assistant"))
        assertThrows(IllegalArgumentException::class.java) { validateRole("system") }
    }

    private fun validateLimit(limit: Int): Int {
        require(limit in 1..100)
        return limit
    }

    private fun validateRole(role: String): String {
        require(role == "user" || role == "assistant")
        return role
    }
}

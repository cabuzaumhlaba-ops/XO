package com.xo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AndroidActionValidationTest {
    @Test
    fun alarmRangeIsValidated() {
        assertTrue(isValidAlarm(23, 59))
        assertFalse(isValidAlarm(24, 0))
        assertFalse(isValidAlarm(8, 60))
    }

    @Test
    fun onlyHttpAndHttpsUrlsAreAccepted() {
        assertTrue(isSafeUrl("https://example.com"))
        assertTrue(isSafeUrl("http://example.com"))
        assertFalse(isSafeUrl("javascript:alert(1)"))
        assertFalse(isSafeUrl("file:///sdcard/test.html"))
    }

    private fun isValidAlarm(hour: Int, minute: Int) = hour in 0..23 && minute in 0..59
    private fun isSafeUrl(value: String): Boolean {
        val uri = runCatching { java.net.URI(value) }.getOrNull()
        return uri?.scheme in setOf("http", "https") && !uri?.host.isNullOrBlank()
    }
}

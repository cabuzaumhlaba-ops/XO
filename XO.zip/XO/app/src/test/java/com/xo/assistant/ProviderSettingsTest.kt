package com.xo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProviderSettingsTest {
    @Test
    fun httpsUrlsAreAcceptedAndHttpUrlsAreRejected() {
        assertTrue(isHttpsUrl("https://api.example.com/v1"))
        assertFalse(isHttpsUrl("http://api.example.com/v1"))
        assertFalse(isHttpsUrl("api.example.com/v1"))
    }

    @Test
    fun chatCompletionsSuffixIsNotDuplicated() {
        assertTrue(chatCompletionsUrl("https://api.example.com/v1") == "https://api.example.com/v1/chat/completions")
        assertTrue(chatCompletionsUrl("https://api.example.com/v1/chat/completions") == "https://api.example.com/v1/chat/completions")
    }

    private fun isHttpsUrl(value: String): Boolean {
        val uri = runCatching { java.net.URI(value) }.getOrNull()
        return uri?.scheme.equals("https", ignoreCase = true) && !uri?.host.isNullOrBlank()
    }

    private fun chatCompletionsUrl(baseUrl: String): String {
        val base = baseUrl.trim().trimEnd('/')
        return if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
    }
}

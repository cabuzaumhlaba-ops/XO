package com.xo.assistant.telegram

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Small Telegram Bot API client. It never logs or persists the bot token. */
class TelegramClient {
    fun sendMessage(botToken: String, chatId: Long, text: String): String {
        require(botToken.isNotBlank()) { "Telegram bot token is not configured." }
        require(text.isNotBlank()) { "Telegram reply cannot be empty." }
        val payload = JSONObject()
            .put("chat_id", chatId)
            .put("text", text)
        val connection = URL("https://api.telegram.org/bot$botToken/sendMessage").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 30_000
            connection.instanceFollowRedirects = false
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val ok = runCatching { JSONObject(body).optBoolean("ok", false) }.getOrDefault(false)
            if (status !in 200..299 || !ok) throw TelegramException("Telegram send failed with HTTP $status.")
            return body
        } finally {
            connection.disconnect()
        }
    }

    fun getUpdates(botToken: String, offset: Long, timeoutSeconds: Int = 25): JSONArray {
        require(botToken.isNotBlank()) { "Telegram bot token is not configured." }
        require(timeoutSeconds in 1..50)
        val query = "offset=$offset&timeout=$timeoutSeconds&allowed_updates=%5B%22message%22%5D"
        val connection = URL("https://api.telegram.org/bot$botToken/getUpdates?$query").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 15_000
            connection.readTimeout = (timeoutSeconds + 15) * 1_000
            connection.instanceFollowRedirects = false
            val status = connection.responseCode
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(body)
            if (status !in 200..299 || !json.optBoolean("ok", false)) {
                throw TelegramException("Telegram getUpdates failed with HTTP $status.")
            }
            return json.optJSONArray("result") ?: JSONArray()
        } finally {
            connection.disconnect()
        }
    }
}

class TelegramException(message: String) : Exception(message)

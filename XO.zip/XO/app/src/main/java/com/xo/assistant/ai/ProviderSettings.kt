package com.xo.assistant.ai

import android.content.Context
import com.xo.assistant.security.EncryptedSecretStore
import java.net.URI

data class ProviderConfig(
    val baseUrl: String,
    val model: String,
    val apiKey: String,
)

class ProviderSettings(context: Context) {
    private val preferences = context.getSharedPreferences("xo-provider-settings", Context.MODE_PRIVATE)
    private val secrets = EncryptedSecretStore(context)

    fun read(): ProviderConfig = ProviderConfig(
        baseUrl = preferences.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL,
        model = preferences.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL,
        apiKey = secrets.get(KEY_API_KEY).orEmpty(),
    )

    fun save(baseUrl: String, model: String, apiKey: String) {
        val normalizedUrl = baseUrl.trim().trimEnd('/')
        val normalizedModel = model.trim()
        val uri = runCatching { URI(normalizedUrl) }.getOrNull()
        require(uri?.scheme.equals("https", ignoreCase = true) && !uri?.host.isNullOrBlank()) {
            "Use an HTTPS provider URL to protect credentials in transit."
        }
        require(normalizedModel.isNotEmpty()) { "Enter a model name." }
        preferences.edit()
            .putString(KEY_BASE_URL, normalizedUrl)
            .putString(KEY_MODEL, normalizedModel)
            .apply()
        if (apiKey.isNotBlank()) secrets.put(KEY_API_KEY, apiKey.trim())
    }

    fun clearKey() = secrets.put(KEY_API_KEY, "")

    private companion object {
        const val KEY_BASE_URL = "base_url"
        const val KEY_MODEL = "model"
        const val KEY_API_KEY = "api_key"
        const val DEFAULT_BASE_URL = "https://api.openai.com/v1"
        const val DEFAULT_MODEL = "gpt-4o-mini"
    }
}

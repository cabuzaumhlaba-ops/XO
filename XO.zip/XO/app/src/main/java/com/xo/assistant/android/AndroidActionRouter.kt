package com.xo.assistant.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings

/** Executes only Android-supported intents and never bypasses user confirmation. */
class AndroidActionRouter(private val context: Context) {
    fun openApp(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun openUrl(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        if (uri.scheme != "http" && uri.scheme != "https") return false
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun setAlarm(hour: Int, minute: Int, label: String): Boolean {
        if (hour !in 0..23 || minute !in 0..59) return false
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.take(120))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun dial(phoneNumber: String): Boolean {
        val digits = phoneNumber.filter { it.isDigit() || it == '+' }
        if (digits.isBlank()) return false
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(digits)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun openSettings(target: SettingsTarget): Boolean {
        val action = when (target) {
            SettingsTarget.SETTINGS -> Settings.ACTION_SETTINGS
            SettingsTarget.SOUND -> Settings.ACTION_SOUND_SETTINGS
            SettingsTarget.WIFI -> Settings.ACTION_WIFI_SETTINGS
            SettingsTarget.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            SettingsTarget.BATTERY -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}

enum class SettingsTarget { SETTINGS, SOUND, WIFI, BLUETOOTH, BATTERY }

package com.xo.assistant.telegram

import android.content.Context
import com.xo.assistant.security.EncryptedSecretStore

class TelegramSettings(context: Context) {
    private val preferences = context.getSharedPreferences("xo-telegram", Context.MODE_PRIVATE)
    private val secrets = EncryptedSecretStore(context)

    fun save(botToken: String, allowedChatIds: Set<Long>) {
        secrets.put(KEY_TOKEN, botToken.trim())
        preferences.edit()
            .putString(KEY_ALLOWED_CHATS, allowedChatIds.joinToString(","))
            .apply()
    }

    fun token(): String = secrets.get(KEY_TOKEN).orEmpty()

    fun allowedChatIds(): Set<Long> = preferences.getString(KEY_ALLOWED_CHATS, "")
        .orEmpty()
        .split(',')
        .mapNotNull { it.trim().toLongOrNull() }
        .toSet()

    fun clear() {
        secrets.put(KEY_TOKEN, "")
        preferences.edit().clear().apply()
    }

    private companion object {
        const val KEY_TOKEN = "telegram_bot_token"
        const val KEY_ALLOWED_CHATS = "telegram_allowed_chat_ids"
    }
}

package com.xo.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xo.assistant.ai.OpenAiCompatibleClient
import com.xo.assistant.ai.ProviderSettings
import com.xo.assistant.data.ConversationMessage
import com.xo.assistant.data.ConversationStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ProviderSettingsView(
    val baseUrl: String,
    val model: String,
    val keyConfigured: Boolean,
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val store = ConversationStore(application)
    private val settings = ProviderSettings(application)
    private val client = OpenAiCompatibleClient()

    private val _messages = MutableStateFlow<List<ConversationMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    private val _sending = MutableStateFlow(false)
    val sending = _sending.asStateFlow()

    private val _status = MutableStateFlow<String?>(null)
    val status = _status.asStateFlow()

    init {
        refreshMessages()
    }

    fun providerSettings(): ProviderSettingsView {
        val config = settings.read()
        return ProviderSettingsView(config.baseUrl, config.model, config.apiKey.isNotEmpty())
    }

    fun saveProvider(baseUrl: String, model: String, apiKey: String) {
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { settings.save(baseUrl, model, apiKey) }
            }.onSuccess {
                _status.value = "Provider settings saved on this device."
            }.onFailure {
                _status.value = it.message ?: "Could not save provider settings."
            }
        }
    }

    fun clearHistory() {
        if (_sending.value) {
            _status.value = "Wait until XO finishes the current response before clearing history."
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.clear() }
            _messages.value = emptyList()
            _status.value = "Conversation history deleted."
        }
    }

    fun clearProviderKey() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { settings.clearKey() }
            _status.value = "Provider key deleted from this device."
        }
    }

    fun dismissStatus() {
        _status.value = null
    }

    fun reportStatus(message: String) {
        _status.value = message
    }

    fun sendPrompt(rawPrompt: String) {
        val prompt = rawPrompt.trim()
        if (prompt.isEmpty() || _sending.value) return

        viewModelScope.launch {
            _sending.value = true
            _status.value = null
            try {
                val config = withContext(Dispatchers.IO) { settings.read() }
                require(config.apiKey.isNotBlank()) { "Add an AI provider key in Settings." }
                val context = withContext(Dispatchers.IO) { store.recent(12) }
                withContext(Dispatchers.IO) { store.add("user", prompt) }
                refreshMessages()
                val answer = withContext(Dispatchers.IO) { client.reply(config, context, prompt) }
                withContext(Dispatchers.IO) { store.add("assistant", answer) }
                refreshMessages()
            } catch (error: Exception) {
                _status.value = error.message ?: "XO could not complete the request."
            } finally {
                _sending.value = false
            }
        }
    }

    private fun refreshMessages() {
        viewModelScope.launch {
            _messages.value = withContext(Dispatchers.IO) { store.recent(100) }
        }
    }

    override fun onCleared() {
        store.close()
        super.onCleared()
    }
}

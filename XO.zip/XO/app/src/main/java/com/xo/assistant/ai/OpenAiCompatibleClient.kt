package com.xo.assistant.ai

import com.xo.assistant.data.ConversationMessage
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class OpenAiCompatibleClient {
    fun reply(config: ProviderConfig, history: List<ConversationMessage>, prompt: String): String {
        require(config.apiKey.isNotBlank()) { "Add an AI provider key in Settings." }
        require(prompt.isNotBlank()) { "Enter a message first." }
        val baseUrl = config.baseUrl.trimEnd('/')
        val endpoint = if (baseUrl.endsWith("/chat/completions")) baseUrl else "$baseUrl/chat/completions"
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
        history.takeLast(MAX_CONTEXT_MESSAGES).forEach { message ->
            messages.put(JSONObject().put("role", message.role).put("content", message.content))
        }
        messages.put(JSONObject().put("role", "user").put("content", prompt))

        val payload = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("temperature", 0.6)
        val connection = URL(endpoint).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.instanceFollowRedirects = false
            connection.doOutput = true
            connection.setRequestProperty("Authorization", "Bearer ${config.apiKey}")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val status = connection.responseCode
            if (status !in 200..299) {
                throw ProviderException("AI provider returned HTTP $status.")
            }
            val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val content = JSONObject(response)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .optString("content")
                .trim()
            if (content.isEmpty()) throw ProviderException("AI provider returned an empty reply.")
            return content
        } finally {
            connection.disconnect()
        }
    }

    private companion object {
        const val CONNECT_TIMEOUT_MS = 15_000
        const val READ_TIMEOUT_MS = 45_000
        const val MAX_CONTEXT_MESSAGES = 12
        const val SYSTEM_PROMPT = "You are XO, a helpful Android assistant. Be clear, honest, and concise. Never claim to have performed a device action unless it was actually executed and verified. Ask before consequential actions."
    }
}

class ProviderException(message: String) : Exception(message)

package com.xo.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.core.content.ContextCompat
import com.xo.assistant.data.ConversationMessage
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            XOTheme {
                AssistantHome()
            }
        }
    }
}

@Composable
private fun XOTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MaterialTheme.colorScheme.copy(
            background = Color(0xFF101513),
            surface = Color(0xFF19211E),
            primary = Color(0xFF9BE3C2),
            onBackground = Color(0xFFE7EEE9),
            onSurface = Color(0xFFE7EEE9),
            onSurfaceVariant = Color(0xFFA8B5AD),
        ),
        content = content,
    )
}

@Composable
private fun AssistantHome(chat: ChatViewModel = viewModel()) {
    val messages by chat.messages.collectAsStateWithLifecycle()
    val sending by chat.sending.collectAsStateWithLifecycle()
    val status by chat.status.collectAsStateWithLifecycle()
    var draft by rememberSaveable { mutableStateOf("") }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    var showMicRationale by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val context = LocalContext.current
    val ttsReady = remember { mutableStateOf(false) }
    val textToSpeech = remember(context) {
        TextToSpeech(context) { result ->
            ttsReady.value = result == TextToSpeech.SUCCESS
        }
    }
    LaunchedEffect(ttsReady.value) {
        if (ttsReady.value) textToSpeech.language = Locale.getDefault()
    }
    DisposableEffect(textToSpeech) {
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }
    val speechIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to XO")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val recognized = if (result.resultCode == Activity.RESULT_OK) {
            result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        } else {
            null
        }
        if (recognized.isNullOrBlank()) chat.reportStatus("Speech was not recognized. Try again or type your message.")
        else draft = recognized
    }
    val microphonePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            runCatching { speechLauncher.launch(speechIntent) }
                .onFailure { chat.reportStatus("Could not start Android speech recognition. Check the speech service on this device.") }
        }
        else chat.reportStatus("Microphone permission was denied. Voice input is unavailable.")
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { insets ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(insets)
                .padding(horizontal = 18.dp, vertical = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(36.dp).background(Color(0xFF9BE3C2), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("X", color = Color(0xFF101513), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("XO", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("Android assistant", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showSettings = true }) { Text("Settings") }
                TextButton(onClick = { confirmClear = true }, enabled = messages.isNotEmpty() && !sending) { Text("Clear") }
            }

            Spacer(Modifier.height(12.dp))
            if (status != null) {
                Surface(color = Color(0xFF352C1E), shape = RoundedCornerShape(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(status.orEmpty(), modifier = Modifier.weight(1f).padding(vertical = 10.dp), fontSize = 13.sp)
                        TextButton(onClick = chat::dismissStatus) { Text("Dismiss") }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            if (messages.isEmpty()) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                    Text("Start a conversation", fontSize = 27.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Connect an OpenAI-compatible provider in Settings. XO keeps conversation history on this device and uses recent turns for context.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(messages, key = ConversationMessage::id) { message ->
                        MessageBubble(message)
                    }
                    if (sending) {
                        item { Text("XO is thinking...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            val latestReply = messages.lastOrNull { it.role == "assistant" }?.content
            if (latestReply != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = {
                            val result = textToSpeech.speak(latestReply, TextToSpeech.QUEUE_FLUSH, null, "xo-latest-reply")
                            if (result == TextToSpeech.ERROR) chat.reportStatus("Android text-to-speech could not start.")
                        },
                        enabled = ttsReady.value,
                    ) { Text("Read reply") }
                    TextButton(onClick = { textToSpeech.stop() }, enabled = ttsReady.value) { Text("Stop speech") }
                }
            }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message XO") },
                    maxLines = 4,
                    enabled = !sending,
                )
                TextButton(
                    onClick = {
                        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                            chat.reportStatus("No Android speech-recognition service is available on this device.")
                        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            runCatching { speechLauncher.launch(speechIntent) }
                                .onFailure { chat.reportStatus("Could not start Android speech recognition. Check the speech service on this device.") }
                        } else {
                            showMicRationale = true
                        }
                    },
                    enabled = !sending,
                    modifier = Modifier.padding(bottom = 10.dp),
                ) {
                    Text("Talk")
                }
                Button(
                    onClick = {
                        chat.sendPrompt(draft)
                        draft = ""
                    },
                    enabled = draft.isNotBlank() && !sending,
                    modifier = Modifier.padding(bottom = 4.dp),
                ) {
                    Text(if (sending) "Wait" else "Send")
                }
            }
        }
    }

    if (showSettings) ProviderSettingsDialog(chat, onDismiss = { showSettings = false })
    if (showMicRationale) {
        AlertDialog(
            onDismissRequest = { showMicRationale = false },
            title = { Text("Allow microphone access?") },
            text = { Text("XO uses Android's speech-recognition service for a single voice input. The speech provider and its data handling depend on your device and settings. XO does not listen in the background.") },
            confirmButton = {
                TextButton(onClick = {
                    showMicRationale = false
                    microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { showMicRationale = false }) { Text("Cancel") }
            },
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete conversation history?") },
            text = { Text("This permanently removes the saved chat from this device.") },
            confirmButton = {
                TextButton(onClick = { chat.clearHistory(); confirmClear = false }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun MessageBubble(message: ConversationMessage) {
    val fromUser = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 320.dp),
            color = if (fromUser) Color(0xFF274A3C) else MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(12.dp),
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp)) {
                Text(if (fromUser) "You" else "XO", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(message.content, fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
    }
}

@Composable
private fun ProviderSettingsDialog(chat: ChatViewModel, onDismiss: () -> Unit) {
    val initial = remember(chat) { chat.providerSettings() }
    var baseUrl by rememberSaveable { mutableStateOf(initial.baseUrl) }
    var model by rememberSaveable { mutableStateOf(initial.model) }
    var apiKey by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AI provider") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("OpenAI-compatible HTTPS endpoint", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("Base URL") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true)
                OutlinedTextField(
                    apiKey,
                    { apiKey = it },
                    label = { Text("API key") },
                    placeholder = { Text(if (initial.keyConfigured) "Saved securely; leave blank to keep" else "Required") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                )
                if (initial.keyConfigured) {
                    Text("The saved key is encrypted with Android Keystore.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { chat.saveProvider(baseUrl, model, apiKey); onDismiss() }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (initial.keyConfigured) {
                    TextButton(onClick = { chat.clearProviderKey(); onDismiss() }) { Text("Delete key") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}

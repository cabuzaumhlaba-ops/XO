package com.xo.assistant.data

data class ConversationMessage(
    val id: Long,
    val role: String,
    val content: String,
    val createdAt: Long,
)

# Build Environment

## Pinned baseline

- JDK: 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Android compile/target SDK: 35
- Minimum Android SDK: 26

The GitHub Actions workflow installs these build prerequisites and runs `:app:assembleDebug`. It uploads `app-debug.apk` only when the build succeeds. CI has not yet been run; adding the workflow is not evidence that an APK compiled.

## Local build

Install JDK 17 and Android SDK platform 35 plus build-tools 35.0.0, then run:

```sh
gradle --no-daemon :app:assembleDebug
```

Do not commit local SDK paths, signing credentials, AI provider keys, or Telegram bot tokens. A local APK build is not a substitute for installing the APK and testing features on a physical Android device.

# XO Status

Last updated: 2026-11-23

| Capability | Status | Evidence / limitation |
|---|---|---|
| Android Kotlin/Compose foundation | NOT TESTED | Source and Gradle configuration created; no local JDK/SDK/Gradle APK build evidence. |
| Complete Gradle wrapper | WORKING — packaging verified | Includes `gradlew`, `gradlew.bat`, JAR and properties. Wrapper execution is not tested until GitHub Actions runs it. |
| Debug APK | NOT TESTED | GitHub Actions workflow exists; no hosted build result is available in this workspace. |
| AI conversations/providers | NOT TESTED | OpenAI-compatible HTTPS client and endpoint/model/key settings exist in source; no provider request or APK build evidence. |
| Short-term conversation history | NOT TESTED | SQLite stores messages and recent turns are included in provider requests. |
| Long-term memory and user controls | NOT IMPLEMENTED | No long-term fact repository or memory-management UI. |
| XO wake word / continuous voice | NOT IMPLEMENTED | No licensed wake model or foreground microphone service. |
| User-initiated speech input | NOT TESTED | Android recognition is wired behind a runtime permission rationale. |
| Spoken replies | NOT TESTED | Android TTS has read/stop controls. |
| Android app/device automation | NOT TESTED | Intent router includes app launch, HTTPS URLs, alarms, dialer and settings. Accessibility automation remains NOT IMPLEMENTED. |
| Notification access | NOT IMPLEMENTED | No notification-listener service or UI. |
| Telegram bot | NOT TESTED | Token/allowlist settings and Bot API send/getUpdates client exist in source; no polling service or live credential test. |
| Offline basic phone actions | NOT TESTED | Source actions exist but require compatible apps and real-device confirmation. |
| Real-device testing | NOT TESTED | No ADB device or physical audio/automation evidence is available. |

No smart-home, finance-tracking, charging-telemetry, or airspace-radar feature is planned.

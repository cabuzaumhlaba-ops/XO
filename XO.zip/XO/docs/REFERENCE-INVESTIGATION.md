# Reference Investigation Record

Date: 2026-11-23
REA: 6.10.1

REA `import-reference-source --detail summary` imported all three local checkouts as `historical-reference`. These operations inventory source trees; they do not execute the apps or prove runtime behavior. REA doctor marked the Android ARM64 host unsupported and reported no configured native analysis providers.

| Reference | Checked out revision | REA inventory | Observations |
|---|---|---|---|
| `AnaaySampat/jarvis` | `a1868c9cc02165e64f82d54d11a6ab3b6553f362` | 680 entries; 580 files; 945 relationships; Kotlin/TypeScript/JavaScript/Rust/HTML/JSON/Markdown | MIT. Tauri 2 shell, React/TypeScript brain, Rust bridge, Kotlin phone plugin. Strongest Android architecture reference. |
| `AbuZar-Ansarii/Jarvis` | `c1f5fb51e1752db9e0465c05afcf2690986f742b` | 184 entries; 140 files; Kotlin/Dart/HTML/JSON/Python/XML/YAML | MIT, Flutter with Kotlin platform channels. `v1.0.2` and `v1.1.0` tags resolve to this same commit, so the requested exact release cannot be distinguished by source commit. |
| `FatihMakes/Mark-X` | `c1...` local checkout | 22 entries; 17 files; Python/Text | README restricts commercial use and source/assets are not copied. Python/Tkinter/Windows audio assumptions are not suitable for Android. No Telegram service was found in the repository inventory. |

REA manifest IDs (for local REA evidence lookup):

- Primary: `hsm_ca3a936c58fc449374b642af63c457385728a249827aa17546d724ababe2630f`
- Secondary: `hsm_bdd0ca6743a5e2bf6b6116688e4fe0d8fe4568de589b38b3296d72f5cd30344c`
- Mark-X: `hsm_9430fe572f4be5585552df996dc0187b49a61fa45d2ac2df0f6627704f03ae69`

Import authority is historical-reference only. REA reported a Linux-host-only native-analysis requirement; no native binary analysis, device run, feature verification, or build verification was performed.

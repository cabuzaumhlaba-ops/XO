# XO Integration and Delivery Plan

## Investigation status

- Primary foundation: `AnaaySampat/jarvis` — MIT license. It is a Tauri 2 / React / TypeScript / Rust / Kotlin Android application. Reusable concepts: native plugin boundaries, wake-word foreground service, AccessibilityService automation, secure secret storage, health/diagnostic reporting, and Android permission UX.
- Secondary reference: `AbuZar-Ansarii/Jarvis` — MIT license. It is Flutter/Dart plus Kotlin MethodChannels. Release metadata is inconsistent: the repository tag `v1.0.2` resolves to commit `c1f5fb5`, which is also tagged `v1.1.0`. XO will use the repository release ZIP/tag as a visual and behavioral reference only, and pin exact source commits if code is ported.
- Windows reference: `FatihMakes/Mark-X` — no OSI license found; README prohibits commercial use, sale, marketing, and claiming it as one's own. XO will not copy its source or assets. Concepts to reproduce independently: short conversation history, intent JSON, follow-up parameter collection, microphone interruption, TTS interruption, and clear action failures.

## Architecture decision

Use native Kotlin + AndroidX + Jetpack Compose for the new XO application. Reimplement Android boundaries independently rather than merging whole repositories. Initial chat history uses SQLite; provider secrets use AES-GCM with an Android Keystore key.

```
Compose UI
  ├─ Conversation and memory screens
  ├─ Permissions and settings
  └─ XO status/voice controls
        │
  AssistantController
  ├─ Intent/AI router
      ├─ Conversation history and long-term memory repositories
  ├─ Tool/task coordinator
  └─ Credential store
        │
  Android services/plugins
  ├─ SpeechRecognition/TTS
  ├─ WakeWord foreground service
  ├─ Accessibility automation
  ├─ Notification listener
  ├─ Intents/phone controls
  └─ Telegram Bot API polling
```

## Licensing and reuse rules

- Reproduce behaviors with original XO code.
- Keep third-party assets/models out of this repository unless a license is verified.
- Preserve attribution for small MIT-compatible snippets if any are used.
- Do not copy Mark-X source, assets, or prompts.
- Do not implement smart home, finance, charging telemetry, or airspace radar.

## Build baseline

- Target Android: API 26–36 where practical.
- Minimum SDK: 26 unless a required Jetpack dependency demands a higher baseline.
- Pin Gradle, AGP, Kotlin, Compose BOM, and Android compile SDK.
- Use Gradle Wrapper and GitHub Actions.
- Pin credentials outside source control.
- Produce `app-debug.apk` and document real-device-only limitations.

## Implementation phases

1. Create native project and verified hello-world APK.
2. Implement Compose chat, an OpenAI-compatible HTTPS provider client, Android Keystore-backed provider secrets, and SQLite-backed recent conversation context.
3. Implement user-initiated SpeechRecognizer/TTS; then separately evaluate wake-word foreground service, audio focus, interruption, and recognition recovery.
4. Implement wake-word service after obtaining a redistributable, independently licensed model or use explicit push-to-talk first.
5. Implement opt-in Accessibility automation with confirmations and risk classification.
6. Implement notification access and phone intents only when user-visible and supported.
7. Implement Telegram long polling with allowlisted chat IDs, secrets outside source, and command routing.
8. Run unit/build/integration tests, real-device smoke tests, and performance checks.

## Feature status definitions

- WORKING: tested on the target runtime or unit test plus build evidence.
- PARTIALLY WORKING: real behavior exists, but one supported path remains unverified.
- NOT IMPLEMENTED: source and runtime path do not exist.
- BROKEN: exists but a test or real execution fails.
- NOT TESTED: no sufficient evidence.

## Initial exclusions

No smart-home control, finance tracking, charging telemetry, airspace radar, network scanning, sentry/anti-theft monitoring, or air gestures. No copied hologram assets or fabricated device controls.

## Unknowns that must be resolved

- Android SDK/JDK availability in this workspace.
- Whether a real Android device is accessible through ADB.
- A user-supplied AI API key/provider.
- A Telegram bot token and allowed chat ID.
- A redistributable wake-word model/license.
